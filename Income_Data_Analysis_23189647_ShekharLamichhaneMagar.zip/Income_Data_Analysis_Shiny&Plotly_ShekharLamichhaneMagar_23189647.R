#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    https://shiny.posit.co/
#

# Install and load required packages
if (!require(shiny)) install.packages("shiny")
if (!require(plotly)) install.packages("plotly")
if (!require(dplyr)) install.packages("dplyr")
if (!require(tidyr)) install.packages("tidyr")

library(shiny)
library(plotly)
library(dplyr)
library(tidyr)

# Assuming 'Income_data_imputed' is loaded
# Income_data_imputed <- read.csv("feature_engineered_data.csv")

# Define UI
ui <- fluidPage(
  titlePanel("Income Data Analysis"),
  sidebarLayout(
    sidebarPanel(
      selectInput("plot_type", "Select Plot Type:",
                  choices = c("Age Distribution", "Income by Education", 
                              "Income by Age Group", "Hours per Week Distribution",
                              "Income by Occupation", "Income by Gender and Race")),
      selectInput("gender_filter", "Filter by Gender:",
                  choices = c("All", unique(Income_data_imputed$gender))),
      selectInput("marital_filter", "Filter by Marital Status:",
                  choices = c("All", unique(Income_data_imputed$marital.status))),
      selectInput("education_filter", "Filter by Education:",
                  choices = c("All", unique(Income_data_imputed$education)))
    ),
    mainPanel(
      plotlyOutput("plot")
    )
  )
)

# Define server logic
server <- function(input, output) {
  
  filtered_data <- reactive({
    data <- Income_data_imputed
    
    if (input$gender_filter != "All") {
      data <- data %>% filter(gender == input$gender_filter)
    }
    
    if (input$marital_filter != "All") {
      data <- data %>% filter(marital.status == input$marital_filter)
    }
    
    if (input$education_filter != "All") {
      data <- data %>% filter(education == input$education_filter)
    }
    
    return(data)
  })
  
  output$plot <- renderPlotly({
    data <- filtered_data()
    
    switch(input$plot_type,
           "Age Distribution" = {
             plot_ly(data, x = ~age, type = "histogram", nbinsx = 30) %>%
               layout(title = "Age Distribution", 
                      xaxis = list(title = "Age"), 
                      yaxis = list(title = "Count"))
           },
           "Income by Education" = {
             data %>%
               count(education, income) %>%
               group_by(education) %>%
               mutate(prop = n / sum(n)) %>%
               plot_ly(x = ~education, y = ~prop, color = ~income, type = "bar") %>%
               layout(title = "Income Distribution by Education", 
                      xaxis = list(title = "Education Level"), 
                      yaxis = list(title = "Proportion"),
                      barmode = "stack")
           },
           "Income by Age Group" = {
             data %>%
               count(age_group, income) %>%
               group_by(age_group) %>%
               mutate(prop = n / sum(n)) %>%
               plot_ly(x = ~age_group, y = ~prop, color = ~income, type = "bar") %>%
               layout(title = "Income Distribution by Age Group", 
                      xaxis = list(title = "Age Group"), 
                      yaxis = list(title = "Proportion"),
                      barmode = "stack")
           },
           "Hours per Week Distribution" = {
             plot_ly(data, x = ~hours.per.week, type = "histogram", nbinsx = 30) %>%
               layout(title = "Hours per Week Distribution", 
                      xaxis = list(title = "Hours per Week"), 
                      yaxis = list(title = "Count"))
           },
           "Income by Occupation" = {
             data %>%
               count(occupation, income) %>%
               group_by(occupation) %>%
               mutate(prop = n / sum(n)) %>%
               plot_ly(x = ~occupation, y = ~prop, color = ~income, type = "bar") %>%
               layout(title = "Income Distribution by Occupation", 
                      xaxis = list(title = "Occupation"), 
                      yaxis = list(title = "Proportion"),
                      barmode = "stack")
           },
           "Income by Gender and Race" = {
             data %>%
               count(gender, race, income) %>%
               group_by(gender, race) %>%
               mutate(prop = n / sum(n)) %>%
               plot_ly(x = ~paste(gender, race, sep = " - "), y = ~prop, color = ~income, type = "bar") %>%
               layout(title = "Income Distribution by Gender and Race", 
                      xaxis = list(title = "Gender - Race"), 
                      yaxis = list(title = "Proportion"),
                      barmode = "stack")
           }
    )
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
